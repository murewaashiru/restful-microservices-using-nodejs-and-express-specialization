const getRequestData = (req) => {
 // Write logic here to read the request body data
}

module.exports = getRequestData