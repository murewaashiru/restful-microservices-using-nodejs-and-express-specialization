getRequestData = (req) => {
  return new Promise((resolve, reject) => {
   // Write logic to read the request body data here
  });
}

module.exports = getRequestData