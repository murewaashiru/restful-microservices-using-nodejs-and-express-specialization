const addition = (num1, num2) => {
  // Write the code here
};

const subtraction = (num1, num2) => {
    // Write the code here
};

module.exports = { multiplication, division };
