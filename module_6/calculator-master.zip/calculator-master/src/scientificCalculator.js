// Return the ceil value of the number, check if the number is < or = zero, then throw an Error
const computeCeil = (number) => {
  
}
// Return the floor value of the number, check if the number is < or = zero, then throw an Error
const computeFloor = (number) => {
  
}
// Return the square root of the number, check if the number is < or = zero, then throw an Error
const computeSquareRoot = (number) => {
  
}
// Return the exponent value of the number, check if the number is < or = zero, then throw an Error
const computePower = (number, powerOf) => {
  
}

module.exports = {
  computeCeil, computeFloor, computeSquareRoot, computePower
}
